#!/bin/bash
check_package() {
    package="$1"
    if ! command -v "$package" &> /dev/null; then
        echo "$package is not installed. Installing..."
        pkg install "$package" -y
        pip install lolcat
    fi
}

# Check if Git is installed
check_package git

# Check if jp2a is installed
check_package jp2a

# Check if jp2a is installed
check_package python-pip

# Colorful ASCII art
echo -e "\e[1;31m  __  __ _______   _                        \e[0m"
echo -e "\e[1;32m |  \/  |__   __| | |                       \e[0m"
echo -e "\e[1;33m | \  / |  | |    | |     ___   __ _  ___   \e[0m"
echo -e "\e[1;34m | |\/| |  | |    | |    / _ \ / _\` |/ _ \  \e[0m"
echo -e "\e[1;35m | |  | |  | |    | |___| (_) | (_| | (_) | \e[0m"
echo -e "\e[1;36m |_|  |_|  |_|    |______\___/ \__, |\___/  \e[0m"
echo -e "\e[1;37m                                __/ |       \e[0m"
echo -e "\e[1;38m                               |___/        \e[0m"

echo "Created by MOwaisAamir"

# Set the folder path based on user selection
echo "Select a folder (1-10):"
read folder_option

case $folder_option in
    1)
        FOLDER_PATH="$(pwd)/folder1"
        ;;
    2)
        FOLDER_PATH="$(pwd)/folder2"
        ;;
    3)
        FOLDER_PATH="$(pwd)/folder3"
        ;;
    4)
        FOLDER_PATH="$(pwd)/folder4"
        ;;
    5)
        FOLDER_PATH="$(pwd)/folder5"
        ;;
    6)
        FOLDER_PATH="$(pwd)/folder6"
        ;;
    7)
        FOLDER_PATH="$(pwd)/folder7"
        ;;
    8)
        FOLDER_PATH="$(pwd)/folder8"
        ;;
    9)
        FOLDER_PATH="$(pwd)/folder9"
        ;;
    10)
        FOLDER_PATH="$(pwd)/folder10"
        ;;
    *)
        echo "Invalid option. Exiting."
        exit 1
        ;;
esac

# Check if either .bashrc or .logo.png file exists in the folder
if [ -e "$FOLDER_PATH/.bashrc" ] || [ -e "$FOLDER_PATH/.logo.png" ]; then
    # Copy .bashrc or .logo.png to Termux home directory
    if [ -e "$FOLDER_PATH/.bashrc" ]; then
        cp "$FOLDER_PATH/.bashrc" "$HOME/"
        echo "Banner was successfully added"
    fi
    if [ -e "$FOLDER_PATH/.logo.png" ]; then
        cp "$FOLDER_PATH/.logo.png" "$HOME/"
        echo "Logo was successfully added"
    fi
    echo "Restart your Termux"
    termux-open-url "https://youtube.com/@reset_your_minds?si=3Cx>"
else
    echo "Error: Banner or logo was not found in the selected folder."
    echo "Contact US: https://youtube.com/@reset_your_minds?si=A>"
fi

